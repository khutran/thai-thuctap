Hey friendly translator! Find all the .po language files in our translation project page:

https://www.transifex.com/projects/p/wysija/

Psss… we give a free Premium to those who contribute.